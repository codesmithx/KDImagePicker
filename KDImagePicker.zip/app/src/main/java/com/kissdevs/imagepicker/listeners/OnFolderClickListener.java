package com.kissdevs.imagepicker.listeners;

import com.kissdevs.imagepicker.model.Picker_Folder;

/**
 * Created by boss1088 on 8/23/16.
 */
public interface OnFolderClickListener {

    void onFolderClick(Picker_Folder bucket);
}
