package com.kissdevs.imagepicker.listeners;

import android.view.View;

/**
 * Created by hoanglam on 8/24/16.
 */
public interface OnImageClickListener {
    void onClick(View view, int position);
}
