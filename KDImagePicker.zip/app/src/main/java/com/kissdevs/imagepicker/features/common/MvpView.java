package com.kissdevs.imagepicker.features.common;

public interface MvpView {
}
